import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';


@Component({
  selector: 'app-user-navbar',
  templateUrl: './user-navbar.component.html',
  styles: []
})
export class UserNavbarComponent implements OnInit {
  decrypt = localStorage.getItem("userToken").toString();
  userId = CryptoJS.AES.decrypt(this.decrypt.trim(), "ut").toString(CryptoJS.enc.Utf8);
  userName = "";
  isFoo: boolean = false;
  constructor(private router: Router, private service: MailboxserviceService) { }

  ngOnInit() {
    this.service.UserLastLogin(this.userId).subscribe(k => {
      this.userName = k['officeName'];
    });
  }
  // ngAfterViewInit() {
  //   $.getScript('assets/js/nifty.min.js');

  // }

  sendtoparent() {
    this.service.buttonClick.next(this.isFoo = !this.isFoo);

  }
  Logout() {
    localStorage.removeItem('userToken');
    this.router.navigate(['/login']);
  }
}