import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import { MailboxserviceService } from '../mailboxservice.service';
@Component({
  selector: 'app-usernotusingmboard',
  templateUrl: './usernotusingmboard.component.html',
  styles: []
})
export class UsernotusingmboardComponent implements OnInit {
  usedUserData: any = [];
  notusedUserData: any = [];
  @ViewChildren(DataTableDirective)
  dtElements: QueryList<any>;
  dtOptions: any = [];
  dtTrigger = new Subject();
  constructor(private service: MailboxserviceService) { }
  displayToConsole(): void {
    this.dtElements.forEach((dtElement: DataTableDirective, index: number) => {
      dtElement.dtInstance.then((dtInstance: any) => {
        console.log(`The DataTable ${index} instance ID is: ${dtInstance.table().node().id}`);
      });
    });
  }
  ngOnInit() {
    this.service.GetUsedUser().subscribe(k => {
      this.usedUserData = k;
      this.dtTrigger.next();
    });
    this.service.GetNotUsedUser().subscribe(k => {
      this.notusedUserData = k;
    });

    this.dtOptions[0] = {
      pageLength: 10, pagingType: 'full_numbers', dom: 'Bfrtip', paging: true, buttons: [
        {
          text: '<i class="fa fa-print"></i> Print',
          extend: 'print',
          title: 'Mandi Parishad Message Board',
          attr: {
            title: 'Print',
          },
          messageTop: 'This print was produced using the Print button for DataTables',
          className: 'btn-primary',
          customize: function (win) {
            $(win.document.body)
              .css('font-size', '10pt')
              .prepend(
                '<img src="http://pngimg.com/uploads/bmw_logo/bmw_logo_PNG19712.png"  style="height:50px;width:50px;position:absolute; top:0; left:0;" />'
              ).prepend(Date);

            $(win.document.body).find('table')
              .addClass('compact')
              .css('font-size', 'inherit');
          }
        }, {
          text: '<i class="fa fa-file-excel-o"></i> Excel',
          extend: 'excel',
          className: 'btn-warning',
          extension: '.xls'
        }, {
          text: '<i class="fa fa-file-pdf-o"></i> Pdf',
          extend: 'pdf',
          className: 'btn-danger',
          extension: '.pdf'
        },
        // 'columnsToggle',
        // 'print',
        // 'excelHtml5',
        // 'pdfHtml5'
      ]
    };
    this.dtOptions[1] = {
      pageLength: 10, pagingType: 'full_numbers', dom: 'Bfrtip', buttons: [
        // 'columnsToggle',
        // 'copy',
        // 'print',
        // 'excelHtml5',
        // 'csvHtml5',
        // 'pdfHtml5'
        {
          text: '<i class="fa fa-print"></i> Print',
          extend: 'print',
          title: 'Report:Who Not Using Mboard',
          className: 'btn-primary',

        }, {
          text: '<i class="fa fa-file-excel-o"></i> Excel',
          extend: 'excel',
          className: 'btn-warning',
          extension: '.xls'
        }, {
          text: '<i class="fa fa-file-pdf-o"></i> Pdf',
          extend: 'pdf',
          className: 'btn-danger',
          extension: '.pdf'
        },
        // 'columnsToggle',
        // 'print',
        // 'excelHtml5',
        // 'pdfHtml5'
      ]
    };
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}
