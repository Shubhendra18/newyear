﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using MandiParishadWebApi.Models;

namespace MandiParishadWebApi.Models
{
    public class UserContext : DbContext
    {
        public UserContext() : base("MandiContext")
        {

        }
        public List<UserInbox> GetUsermail(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@Rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewInboxMail @Rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public UserInbox GetUsermailDetails(MailDes mailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@msgId",Value=mailDes.MailId},
                new SqlParameter {ParameterName="@Rid",Value=mailDes.Rid }

                 };
            var sqlQuery = @"Sp_NewMailDes @msgId,@Rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public UserInbox GetUserDraftDetails(MailDes mailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@msgId",Value=mailDes.MailId},
                new SqlParameter {ParameterName="@Rid",Value=mailDes.Rid }

                 };
            var sqlQuery = @"Sp_draftDes @msgId,@Rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<AttachmentModel> Getattachments(MailDes mailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@msgId",Value=mailDes.MailId},
                new SqlParameter {ParameterName="@Rid",Value=mailDes.Rid }

                 };
            var sqlQuery = @"Sp_Newgetattachment @msgId,@Rid";
            List<AttachmentModel> res = this.Database.SqlQuery<AttachmentModel>(sqlQuery, sqlParam).ToList();
            return res;
        }

        public string DeleteFromTrash(Int64 MailId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=MailId}
                 };
            var sqlQuery = @"Sp_NewDeleteFromTrash @mailid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }

        //**********************Has to be update later
        public string Draftmail(int Priority, bool? SMS, string Subject, string Message, Int64 Sid, string msgid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@priority",Value=Priority},
                new SqlParameter {ParameterName="@sms",Value=SMS} ,
                new SqlParameter {ParameterName="@sub",Value=Subject} ,
                new SqlParameter {ParameterName="@msg",Value=Message},
                new SqlParameter {ParameterName="@sid",Value=Sid},
                new SqlParameter {ParameterName="@messageid",Value=msgid}
                 };
            var sqlQuery = @"Sp_NewDraftMail @priority,@sms,@sub,@msg,@sid,@messageid";
            string res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserInbox> GetFromDraft(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewGetAllFromDraft @rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string MoveToTrash(Int64 MailId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=MailId}
                 };
            var sqlQuery = @"Sp_NewMovetoTrash @mailid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string AllMailMoveToTrash(Int64 Rid,int flag)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid},
                 new SqlParameter {ParameterName="@flag",Value=flag}
                 };
            var sqlQuery = @"Sp_NewAllMailToTrash @rid,@flag";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserInbox> GetFromTrash(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewMailStoredInTrash @rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string MoveToArchive(Int64 MailId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=MailId}
                 };
            var sqlQuery = @"Sp_NewMovetoArchive @mailid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string AllMailMoveToArchive(Int64 Rid,int flag)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid},
                new SqlParameter {ParameterName="@flag",Value=flag},
                 };
            var sqlQuery = @"Sp_NewSendAllMailToArchive @rid,@flag";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserInbox> GetFromArchive(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewGetMailStoredInArchive @rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string MovebackToInbox(MoveToInbox moveTo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=moveTo.mailId},
                new SqlParameter {ParameterName="@flag",Value=moveTo.flag}
                 };
            var sqlQuery = @"Sp_NewSendBackToInbox @mailid,@flag";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string MoveToImportant(Int64 MailId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=MailId}
                 };
            var sqlQuery = @"Sp_NewAddToImportant @mailid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserInbox> GetFromImportant(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewGetAllFromImportant @rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }

        public string ForgetPass(string mobile, string OTP)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mobile",Value=mobile},
                new SqlParameter {ParameterName="@Otp",Value=OTP},
                 };
            var sqlQuery = @"Sp_NewGetUserMobileUpdateOtp @mobile,@Otp";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public AfterverifyOTP VerifyOTP(verifyOTP verifyOTP)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mobile",Value=verifyOTP.mobileNo},
                new SqlParameter {ParameterName="@OTP",Value=verifyOTP.OTP},
                 };
            var sqlQuery = @"Sp_NewVerifyUserMobile @OTP,@mobile";
            var res = this.Database.SqlQuery<AfterverifyOTP>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string ChangePassword(ChangePassword changePassword)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=changePassword.userId},
                new SqlParameter {ParameterName="@Password",Value=changePassword.Password},
                 };
            var sqlQuery = @"Sp_NewChangeUserPass @userId,@Password";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string Attachment(AttachmentModel model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=model.MailId},
                new SqlParameter {ParameterName="@attachment",Value=model.Attachment},
                new SqlParameter {ParameterName="@type",Value=model.AttachmentType},
                new SqlParameter {ParameterName="@replyid",Value=model.ReplyId},
                 };
            var sqlQuery = @"Sp_NewAttachments @mailid,@attachment,@replyid,@type";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserSentMail> GetFromSent(Int64 Sid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@sid",Value=Sid}
                 };
            var sqlQuery = @"Sp_NewGetSentMails @sid";
            var res = this.Database.SqlQuery<UserSentMail>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public UserSentMail GetSentmailDes(SendMailDes sendMailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@sid",Value=sendMailDes.userId},
                new SqlParameter {ParameterName="@messageid",Value=sendMailDes.MessageId}

                 };
            var sqlQuery = @"Sp_NewGetSentMailsDes @sid,@messageid";
            var res = this.Database.SqlQuery<UserSentMail>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }

        public string CheckOldPass(CheckOldPass checkOldPass)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=checkOldPass.userId},
                new SqlParameter {ParameterName="@oldpass",Value=checkOldPass.OldPass},
                 };
            var sqlQuery = @"Sp_NewCheckOldPassword @userId,@oldpass";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public Int64 mailReply(MailReply mailReply)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@sid",Value=mailReply.Sid},
                new SqlParameter {ParameterName="@rid",Value=mailReply.Rid},
                new SqlParameter {ParameterName="@messageid",Value=mailReply.MessageId},
                new SqlParameter {ParameterName="@msg",Value=mailReply.Message},
                new SqlParameter {ParameterName="@priority",Value=mailReply.Priority},
                new SqlParameter {ParameterName="@sub",Value=mailReply.Subject}

                 };
            var sqlQuery = @"Sp_NewSendReply @sid,@rid,@messageid,@msg,@priority,@sub";
            var res = this.Database.SqlQuery<Int64>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<ShowReply> GetmailReplies(SendMailDes sendMailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@msgId",Value=sendMailDes.MessageId},
                new SqlParameter {ParameterName="@sid",Value=sendMailDes.userId}
                 };
            var sqlQuery = @"Sp_NewgetAllReply @msgId,@sid";
            var res = this.Database.SqlQuery<ShowReply>(sqlQuery, sqlParam).ToList();
            return res;
        }
       
    }
}