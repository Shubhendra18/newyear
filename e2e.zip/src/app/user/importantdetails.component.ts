import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';
import { saveAs } from 'file-saver';



@Component({
  selector: 'app-importantdetails',
  templateUrl: './importantdetails.component.html',
  styles: []
})
export class ImportantdetailsComponent implements OnInit {
  decrypt = localStorage.getItem("userToken").toString();
  Rid = CryptoJS.AES.decrypt(this.decrypt.trim(), "ut").toString(CryptoJS.enc.Utf8);

  private maildetails: any = {};
  attachments: any = [];
  mailreplies: any = [];

  attachmentcount: number = 0;
  senderid: any;
  receiverid: any;
  messageID: any;
  priority: any;
  subject: any;
  mailtype: string;
  mailheadstatus: boolean;
  isactive: boolean;
  rowid: any;
  status: any;
  files: File[] = [];
  baseurl: any = "";
  constructor(private service: MailboxserviceService, private route: ActivatedRoute, private toastr: ToastrService) {
    this.baseurl = this.service.getbaseurl();

  }

  ngOnInit() {
    this.service.buttonClick.subscribe(data => {
      this.status = data;
    })

    this.route.paramMap.subscribe(params => {
      var mailDes = { "mailId": params.get('iml'), "msgId": params.get('ims'), "rid": this.Rid };

      this.service.getmailDetails(mailDes).subscribe(k => {
        this.maildetails = k;
        this.senderid = k['rid'];
        this.receiverid = k['userId'];
        this.messageID = k['messageID'];
        this.priority = k['priority'];
        this.subject = k['subject'];
        this.mailtype = k['mailType'];
      })
    });

  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  config = {
    placeholder: 'Your message here..',
    tabsize: 2,
    height: 130,
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph']],
    ],
    fontNames: ['Arial', 'Arial Black', 'Roboto', 'Times']
  }
  SendReply(MailReply) {
    this.service.SendMailReply(this.files, this.senderid, this.receiverid, MailReply.value.Message, this.messageID, this.priority, this.subject).subscribe(k => {
      if (k == "success") {
        this.toastr.info('Reply Send!', 'Success');
        this.files.length = 0;
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Reply!', 'Error');
      }
    });
  }
  Download(attachment) {
    console.log(attachment);
    this.service.DownloadAttachments(attachment).subscribe(k => {
      saveAs(k, attachment);
    });
  }
  uploadFile(event) {
    for (let index = 0; index < event.length; index++) {
      const element = event[index];
      this.service.FileHandle(element).subscribe(
        data => {
          this.files.push(element);
        }, (err: HttpErrorResponse) => {
          if (err.status === 400) {
            Swal.fire({
              icon: 'warning',
              title: err.error.message,
              text: "Warning",
            })
          };
        }
      );
    }
  }

  deleteAttachment(index) {
    this.files.splice(index, 1)
  }
  reset() {
    this.files.length = 0;
  }
}
