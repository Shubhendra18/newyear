import { Component, OnInit, ViewChildren, QueryList } from '@angular/core';
import { DatepickerOptions } from 'ng2-datepicker';
import * as frLocale from 'date-fns/locale/fr';
import * as enLocale from 'date-fns/locale/en';
import { MailboxserviceService } from '../mailboxservice.service';
@Component({
  selector: 'app-msg-report',
  templateUrl: './msg-report.component.html',
  styles: []
})
export class MsgReportComponent implements OnInit {
  tblsub = true;
  tbluser = true;
  tbldate = true;
  sdate: Date;
  edate: Date;
  officename: any = [];

  byOfficeData: any = [];
  bysubjectData: any = [];
  bydateData: any = [];
  p: number = 1;
  userid: any;
  constructor(private service: MailboxserviceService) {
    this.sdate = new Date();
    this.edate = new Date();
  }
  
  ngOnInit() {
    this.service.GetallOffieName().subscribe(k => {
      this.officename = k;
    });
   
  }
  options: DatepickerOptions = {
    minYear: 2010,
    maxYear: 2020,
    displayFormat: 'MMM D[,] YYYY',
    barTitleFormat: 'MMMM YYYY',
    dayNamesFormat: 'dd',
    firstCalendarDay: 1, // 0 - Sunday, 1 - Monday
    locale: enLocale,
    maxDate: new Date(Date.now()),  // Maximal selectable date
  };
  onSelect(value) {
    this.userid = value;
  }

  searchnysubject(subject) {
    this.tbluser = true;
    this.tblsub = false;
    this.tbldate = true;
    this.service.ReportBysubject(subject).subscribe(k => {
      this.bysubjectData = k;
    });

  }
  searchbyDate(sdate, edate) {
    this.tbluser = true;
    this.tblsub = true;
    this.tbldate = false;
    var date = { 'sdate': sdate, 'edate': edate };
    this.service.ReportBydate(date).subscribe(k => {
      this.bydateData = k;
    });


  }
  SearchbyofficeName() {
    this.tbluser = false;
    this.tblsub = true;
    this.tbldate = true;
    this.service.ReportByOfficeName(this.userid).subscribe(k => {
      this.byOfficeData = k;
    });

  }
}
