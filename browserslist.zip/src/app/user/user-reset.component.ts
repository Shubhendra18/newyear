import { Component, OnInit } from '@angular/core';
import { MailboxserviceService } from '../mailboxservice.service';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-user-reset',
  templateUrl: './user-reset.component.html',
  styles: []
})
export class UserResetComponent implements OnInit {
  imageUrl: string = "assets/img/default.png";
  defaultPic: string;
  fileToUpload: File = null;
  constructor(private service: MailboxserviceService, private toastr: ToastrService) { }

  ngOnInit() {
  }
  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);
    this.service.FileHandle(this.fileToUpload).subscribe(
      data => {
        this.toastr.success('Sample Send!', 'Success');
        this.imageUrl = "/assets/img/default.png";
      }, (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.success(err.error.message, 'warning');
        };
      }
    );
  }
  profileUpdate(ProfilePic) {
    this.service.FileHandle(this.fileToUpload).subscribe(
      data => {
        this.toastr.success('Sample Send!', 'Success');
        ProfilePic.value = null;
        this.imageUrl = "/assets/img/default.png";
      }, (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.success(err.error.message, 'warning');
        };
      }
    );
  }
}
