
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';

@Component({
  selector: 'app-user-archive',
  templateUrl: './user-archive.component.html',
  styles: []
})
export class UserArchiveComponent implements OnInit {
  private allmails: any = [];
  SelectedIDs: any = [];
  allmailtotrash: boolean = false;
  Rid = localStorage.getItem("userToken");
  status: any;
  constructor(private service: MailboxserviceService, private toastr: ToastrService) { }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.buttonClick.subscribe(data => {
      this.status = data;
    })

    this.service.allMailFromArchive(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  BackToInbox(mailId) {
    var moveToInbox = { "mailId": mailId, "flag": 0 };
    this.service.backToInbox(moveToInbox).subscribe(k => {
      if (k == "success") {
        this.toastr.success('moved To Inbox!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Inbox!', 'Error');
      }
    });
  }
  FieldsChange(values: any, mailId) {
    this.SelectedIDs.push(mailId);
  }
  deleteSelected() {
    if (this.allmailtotrash == true) {
      var moveToTrash = { 'Rid': this.Rid, 'flag': 3 };
      this.service.allMailsmoveToTrash(moveToTrash).subscribe(k => {
        if (k == "success") {
          this.toastr.success('Moved To Trash!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Trash!', 'Error');
        }
      });
    }
    else {
      this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
        if (k == "Success") {
          this.toastr.info('Moved To Trash!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Trash!', 'Error');
        }
      });
    }
  }
  alltotrash(values: any) {
    this.allmailtotrash = (values.currentTarget.checked);
  }
}
