import { Component, OnInit } from '@angular/core';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-page-head',
  templateUrl: './page-head.component.html',
  styles: []
})
export class PageHeadComponent implements OnInit {
 
  // decrypt = localStorage.getItem("userToken").toString();
  // Rid = CryptoJS.AES.decrypt(this.decrypt.trim(), "ut").toString(CryptoJS.enc.Utf8);

 
  // decryptnew = localStorage.getItem("Token").toString();
  // adminId = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);

  lastlogin: any;
  constructor(private service: MailboxserviceService) { }

  ngOnInit() {
    // this.service.UserLastLogin(this.Rid || this.adminId).subscribe(k => {
    //   this.lastlogin = k['lastLogin'];
    // });
  }

}
