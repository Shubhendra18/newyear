import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';

@Component({
  selector: 'app-user-navbar',
  templateUrl: './user-navbar.component.html',
  styles: []
})
export class UserNavbarComponent implements OnInit {
  userId = localStorage.getItem("userToken");
  userName = "";
  constructor(private router: Router, private service: MailboxserviceService, ) { }

  ngOnInit() {
    this.service.UserLastLogin(this.userId).subscribe(k => {
      this.userName = k['officeName'];
    });
  }
  // ngAfterViewInit() {
  //   $.getScript('assets/js/nifty.min.js');

  // }
  Logout() {
    localStorage.removeItem('userToken');
    this.router.navigate(['/login']);
  }
}