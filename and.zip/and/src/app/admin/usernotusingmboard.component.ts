import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import { MailboxserviceService } from '../mailboxservice.service';
@Component({
  selector: 'app-usernotusingmboard',
  templateUrl: './usernotusingmboard.component.html',
  styles: []
})
export class UsernotusingmboardComponent implements OnInit {
  usedUserData: any = [];
  notusedUserData: any = [];
  @ViewChildren(DataTableDirective)
  dtElements: QueryList<any>;
  dtOptions: any = [];
  dtTrigger = new Subject();
  constructor(private service: MailboxserviceService) { }
  displayToConsole(): void {
    this.dtElements.forEach((dtElement: DataTableDirective, index: number) => {
      dtElement.dtInstance.then((dtInstance: any) => {
        console.log(`The DataTable ${index} instance ID is: ${dtInstance.table().node().id}`);
      });
    });
  }
  ngOnInit() {
    this.service.GetUsedUser().subscribe(k => {
      this.usedUserData = k;
      this.dtTrigger.next();
    });
    this.service.GetNotUsedUser().subscribe(k => {
      this.notusedUserData = k;
    });

    this.dtOptions[0] = {
      pageLength: 10, pagingType: 'full_numbers', dom: 'Bfrtip', buttons: [
        'columnsToggle',
        'print',
        'excelHtml5',
        'pdfHtml5'
      ]
    };
    this.dtOptions[1] = {
      pageLength: 10, pagingType: 'full_numbers', dom: 'Bfrtip', buttons: [
        // 'columnsToggle',
        // 'copy',
        // 'print',
        // 'excelHtml5',
        // 'csvHtml5',
        // 'pdfHtml5'
        'columnsToggle',
        'print',
        'excelHtml5',
        'pdfHtml5'
      ]
    };
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}
