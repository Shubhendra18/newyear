import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { MailboxserviceService } from '../mailboxservice.service';
import { AnonymousSubject } from 'rxjs/internal/Subject';

@Component({
  selector: 'app-user-trash',
  templateUrl: './user-trash.component.html',
  styles: []
})
export class UserTrashComponent implements OnInit {
  private allmails: any = [];
  SelectedIDs: any = [];
  allmailtotrash: boolean = false;
  Rid = localStorage.getItem("userToken");
  status: any;
  constructor(private service: MailboxserviceService, private toastr: ToastrService) { }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.buttonClick.subscribe(data => {
      this.status = data;
    })

    this.service.allMailFromTrash(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  DeleteTrash(mailId) {
    this.service.deleteFromTrash(mailId).subscribe(k => {
      if (k == "Success") {
        this.toastr.success('Deleted From Trash!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Trash!', 'Error');
      }
    });
  }
  EmpltyTrash() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Empty it!'
    }).then((result) => {
      if (result.value) {
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }
  BackToInbox(mailId) {
    var moveToInbox = { "mailId": mailId, "flag": 2 };
    this.service.backToInbox(moveToInbox).subscribe(k => {
      if (k == "success") {
        this.toastr.success('moved To Inbox!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Inbox!', 'Error');
      }
    });
  }
}
