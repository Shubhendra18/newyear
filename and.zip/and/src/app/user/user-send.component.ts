
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';

@Component({
  selector: 'app-user-send',
  templateUrl: './user-send.component.html',
  styles: []
})
export class UserSendComponent implements OnInit {
  private allmails: any = [];
  SelectedIDs: any = [];
  allmailtotrash: boolean = false;
  Rid = localStorage.getItem("userToken");

  constructor(private service: MailboxserviceService, private toastr: ToastrService) { }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.allMailFromSent(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  FieldsChange(values: any, mailId) {
    this.SelectedIDs.push(mailId);
    console.log(values.currentTarget.checked + " " + mailId);
  }
  // deleteSelected() {
  //   if (this.allmailtotrash == true) {
  //     this.service.allMailsmoveToTrash(this.Rid).subscribe(k => {
  //       if (k == "success") {
  //         this.toastr.success('Inbox is Empty!', 'Success');
  //         this.ngOnInit();
  //       }
  //       else {
  //         this.toastr.error('Failed to Moved To Trash!', 'Error');
  //       }
  //     });
  //   }
  //   else {
  //     this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
  //       if (k == "Success") {
  //         this.toastr.info('Moved To Trash!', 'Success');
  //         this.ngOnInit();
  //       }
  //       else {
  //         this.toastr.error('Failed to Moved To Trash!', 'Error');
  //       }
  //     });
  //   }
  // }
  alltotrash(values: any) {
    this.allmailtotrash = (values.currentTarget.checked);
  }
}
