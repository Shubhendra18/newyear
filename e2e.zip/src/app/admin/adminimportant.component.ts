import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';


@Component({
  selector: 'app-adminimportant',
  templateUrl: './adminimportant.component.html',
  styles: []
})
export class AdminimportantComponent implements OnInit {
  private allmails: any = [];
  SelectedIDs: any = [];
  allmailtotrash: boolean = false;
  decryptnew = localStorage.getItem("Token").toString();
  Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);
  baseurl: any = "";
  constructor(private service: MailboxserviceService, private toastr: ToastrService) {
    this.baseurl = this.service.getbaseurl();

  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.allMailFromImportant(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  FieldsChange(values: any, mailId) {
    this.SelectedIDs.push(mailId);
    console.log(values.currentTarget.checked + " " + mailId);
  }
  deleteSelected() {
    if (this.allmailtotrash == true) {
      var moveToTrash = { 'Rid': this.Rid, 'flag': 1 };
      this.service.allMailsmoveToTrash(moveToTrash).subscribe(k => {
        if (k == "success") {
          this.toastr.success('Moved To Trash!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Trash!', 'Error');
        }
      });
    }
    else {
      this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
        if (k == "Success") {
          this.toastr.info('Moved To Trash!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Trash!', 'Error');
        }
      });
    }
  }
  archivedSelected() {
    if (this.allmailtotrash == true) {
      var moveToArchive = { 'Rid': this.Rid, 'flag': 1 };
      this.service.allMailsmoveToArchive(moveToArchive).subscribe(k => {
        if (k == "success") {
          this.toastr.success('Moved To Archived!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Archived!', 'Error');
        }
      });
    }
    else {
      this.service.moveToArchive(this.SelectedIDs).subscribe(k => {
        if (k == "Success") {
          this.toastr.info('Moved To Archived!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Archived!', 'Error');
        }
      });
    }
  }
  alltotrash(values: any) {
    this.allmailtotrash = (values.currentTarget.checked);
  }
}
