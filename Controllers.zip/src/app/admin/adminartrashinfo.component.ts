import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';



@Component({
  selector: 'app-adminartrashinfo',
  templateUrl: './adminartrashinfo.component.html',
  styles: []
})
export class AdminartrashinfoComponent implements OnInit {
  decryptnew = localStorage.getItem("Token").toString();
  Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);
  private maildetails: any = {};
  attachments: any = [];
  mailreplies: any = [];

  attachmentcount: number = 0;
  senderid: any;
  receiverid: any;
  messageID: any;
  constructor(private service: MailboxserviceService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      var mailDes = { "mailId": params.get('atrashid'), "rid": this.Rid };
      this.service.getmailDetails(mailDes).subscribe(k => {
        this.maildetails = k;
        this.senderid = k['rid'];
        this.receiverid = k['userId'];
        this.messageID = k['messageID'];

      })
      this.service.getattachments(mailDes).subscribe(k => {
        this.attachments = k;
        this.attachmentcount = this.attachments.length;
      })
      var sendMailDes = { "MessageId": params.get('atrashid'), "userId": this.Rid };
      this.service.ShowMailReply(sendMailDes).subscribe(k => {
        this.mailreplies = k;
      })
    });

  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  config = {
    placeholder: 'Your message here..',
    tabsize: 2,
    height: 130,
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph']],
    ],
    fontNames: ['Arial', 'Arial Black', 'Roboto', 'Times']
  }
  SendReply(MailReply) {
    this.service.SendMailReply(MailReply.value).subscribe(k => {
      this.ngOnInit();
    });
  }
}
