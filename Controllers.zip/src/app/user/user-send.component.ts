
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';


@Component({
  selector: 'app-user-send',
  templateUrl: './user-send.component.html',
  styles: []
})
export class UserSendComponent implements OnInit {
  private allmails: any = [];
  SelectedIDs: any = [];
  allmailtotrash: boolean = false;
  decrypt = localStorage.getItem("userToken").toString();
  Rid = CryptoJS.AES.decrypt(this.decrypt.trim(), "ut").toString(CryptoJS.enc.Utf8);
  
  status: any;
  constructor(private service: MailboxserviceService, private toastr: ToastrService) { }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.buttonClick.subscribe(data => {
      this.status = data;
    })


    this.service.allMailFromSent(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  FieldsChange(values: any, mailId) {
    this.SelectedIDs.push(mailId);
    console.log(values.currentTarget.checked + " " + mailId);
  }
  // deleteSelected() {
  //   if (this.allmailtotrash == true) {
  //     this.service.allMailsmoveToTrash(this.Rid).subscribe(k => {
  //       if (k == "success") {
  //         this.toastr.success('Inbox is Empty!', 'Success');
  //         this.ngOnInit();
  //       }
  //       else {
  //         this.toastr.error('Failed to Moved To Trash!', 'Error');
  //       }
  //     });
  //   }
  //   else {
  //     this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
  //       if (k == "Success") {
  //         this.toastr.info('Moved To Trash!', 'Success');
  //         this.ngOnInit();
  //       }
  //       else {
  //         this.toastr.error('Failed to Moved To Trash!', 'Error');
  //       }
  //     });
  //   }
  // }
  alltotrash(values: any) {
    this.allmailtotrash = (values.currentTarget.checked);
  }
}
