import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserInboxComponent } from './user/user-inbox.component';
import { UserComposeComponent } from './user/user-compose.component';
import { UserLoginComponent } from './user/user-login.component';
import { AdminLoginComponent } from './admin/admin-login.component';
import { AdminDashboardComponent } from './admin/admin-dashboard.component';
import { ManageGroupComponent } from './admin/manage-group.component';
import { ManageUserComponent } from './admin/manage-user.component';
import { UserlistComponent } from './admin/user-list.component';
import { ResetPassComponent } from './admin/reset-pass.component';
import { BroadcastComponent } from './admin/broadcast.component';
import { SendReceivestatsComponent } from './admin/send-receivestats.component';
import { UsernotusingmboardComponent } from './admin/usernotusingmboard.component';
import { LastloginComponent } from './admin/lastlogin.component';
import { MsgReportComponent } from './admin/msg-report.component';
import { AdminprofileComponent } from './admin/admin-profile.component';
import { UserInboxInfoComponent } from './user/user-inbox-info.component';
import { UserSendComponent } from './user/user-send.component';
import { UserImportantComponent } from './user/user-important.component';
import { UserDraftComponent } from './user/user-draft.component';
import { UserDraftComposeComponent } from './user/user-draft-compose.component';
import { UserArchiveComponent } from './user/user-archive.component';
import { UserTrashComponent } from './user/user-trash.component';
import { UserForgetComponent } from './user/user-forget.component';
import { UserResetComponent } from './user/user-reset.component';
import { UserProfileComponent } from './user/user-profile.component';
import { SentmailDesComponent } from './user/sentmail-des.component';
import { ErrorpageComponent } from './common/errorpage.component';
import { ImportantdetailsComponent } from './user/importantdetails.component';
import { ArchivedetailsComponent } from './user/archivedetails.component';
import { TrashdetailsComponent } from './user/trashdetails.component';
import { AdminmailboxComponent } from './admin/adminmailbox.component';
import { AdminmailboxinfoComponent } from './admin/adminmailboxinfo.component';
import { AdmincreateComponent } from './admin/admincreate.component';
import { AdminsentmailComponent } from './admin/adminsentmail.component';
import { AdminsentdetailsComponent } from './admin/adminsentdetails.component';
import { AdminimportantComponent } from './admin/adminimportant.component';
import { AdminimportantinfoComponent } from './admin/adminimportantinfo.component';
import { AdmindraftComponent } from './admin/admindraft.component';
import { AdmindraftcomComponent } from './admin/admindraftcom.component';
import { AdminarchiveComponent } from './admin/adminarchive.component';
import { AdminarchiveinfoComponent } from './admin/adminarchiveinfo.component';
import { AdminartrashComponent } from './admin/adminartrash.component';
import { AdminartrashinfoComponent } from './admin/adminartrashinfo.component';
import { AuthGuard } from './gaurds/auth.guard';
import { AdminauthGuard } from './gaurds/adminauth.guard';
import { BroadcaststatsComponent } from './admin/broadcaststats.component';



const routes: Routes = [
  //********************User Routes************************/
  { path: 'login', component: UserLoginComponent },
  { path: 'inbox', component: UserInboxComponent, canActivate: [AuthGuard] },
  { path: 'details/:ml/:ms', component: UserInboxInfoComponent, canActivate: [AuthGuard] },
  { path: 'compose', component: UserComposeComponent, canActivate: [AuthGuard] },
  { path: 'sent', component: UserSendComponent, canActivate: [AuthGuard] },
  { path: 'sentDetails/:messageid', component: SentmailDesComponent, canActivate: [AuthGuard] },
  { path: 'important', component: UserImportantComponent, canActivate: [AuthGuard] },
  { path: 'importantinfo/:iml/:ims', component: ImportantdetailsComponent, canActivate: [AuthGuard] },
  { path: 'draft', component: UserDraftComponent, canActivate: [AuthGuard] },
  { path: 'draftcom/:mailid', component: UserDraftComposeComponent, canActivate: [AuthGuard] },
  { path: 'archive', component: UserArchiveComponent, canActivate: [AuthGuard] },
  { path: 'archiveinfo/:arml/:arms', component: ArchivedetailsComponent, canActivate: [AuthGuard] },
  { path: 'trash', component: UserTrashComponent, canActivate: [AuthGuard] },
  { path: 'trashinfo/:tml/:tms', component: TrashdetailsComponent, canActivate: [AuthGuard] },
  { path: 'forget', component: UserForgetComponent },
  { path: 'reset', component: UserResetComponent, canActivate: [AuthGuard] },
  { path: 'profile', component: UserProfileComponent, canActivate: [AuthGuard] },


  //********************Admin Login*************************/
  { path: 'admin', component: AdminLoginComponent },
  { path: 'dashboard', component: AdminDashboardComponent, canActivate: [AdminauthGuard] },
  { path: 'managegroup', component: ManageGroupComponent, canActivate: [AdminauthGuard] },
  { path: 'manageuser', component: ManageUserComponent, canActivate: [AdminauthGuard] },
  { path: 'userlist', component: UserlistComponent, canActivate: [AdminauthGuard] },
  { path: 'resetPassword', component: ResetPassComponent },
  { path: 'broadcast', component: BroadcastComponent, canActivate: [AdminauthGuard] },
  { path: 'broadstats', component: BroadcaststatsComponent, canActivate: [AdminauthGuard] },
  { path: 'statistics', component: SendReceivestatsComponent, canActivate: [AdminauthGuard] },
  { path: 'usernoactivated', component: UsernotusingmboardComponent, canActivate: [AdminauthGuard] },
  { path: 'lastloginrpt', component: LastloginComponent, canActivate: [AdminauthGuard] },
  { path: 'messagerpt', component: MsgReportComponent, canActivate: [AdminauthGuard] },
  { path: 'adminprofile', component: AdminprofileComponent, canActivate: [AdminauthGuard] },

  { path: 'mailbox', component: AdminmailboxComponent, canActivate: [AdminauthGuard] },
  { path: 'mailinfo/:aml/:ams', component: AdminmailboxinfoComponent, canActivate: [AdminauthGuard] },
  { path: 'create', component: AdmincreateComponent, canActivate: [AdminauthGuard] },
  { path: 'sentmail', component: AdminsentmailComponent, canActivate: [AdminauthGuard] },
  { path: 'sendDetails/:amessageid', component: AdminsentdetailsComponent, canActivate: [AdminauthGuard] },
  { path: 'aimportant', component: AdminimportantComponent, canActivate: [AdminauthGuard] },
  { path: 'aimportantinfo/:aiml/:aims', component: AdminimportantinfoComponent, canActivate: [AdminauthGuard] },
  { path: 'admindraft', component: AdmindraftComponent, canActivate: [AdminauthGuard] },
  { path: 'admindraftcom/:amailid', component: AdmindraftcomComponent, canActivate: [AdminauthGuard] },
  { path: 'adminarchive', component: AdminarchiveComponent, canActivate: [AdminauthGuard] },
  { path: 'adminarchiveinfo/:aarml/:aarms', component: AdminarchiveinfoComponent, canActivate: [AdminauthGuard] },
  { path: 'admintrash', component: AdminartrashComponent, canActivate: [AdminauthGuard] },
  { path: 'admintrashinfo/:atml/:atms', component: AdminartrashinfoComponent, canActivate: [AdminauthGuard] },
  //********************Default************************/
  { path: 'error', component: ErrorpageComponent },
  { path: 'encrypt', component: UserResetComponent },

  { path: '', component: UserLoginComponent },
  { path: '**', redirectTo: '/error', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
