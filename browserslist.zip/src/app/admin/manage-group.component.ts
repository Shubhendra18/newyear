
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';
import { MailboxserviceService } from '../mailboxservice.service';

declare var $;
@Component({
  selector: 'app-manage-group',
  templateUrl: './manage-group.component.html',
  styles: []
})
export class ManageGroupComponent implements OnInit, OnDestroy {
  groupData: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  userId = localStorage.getItem("Token");
  toUpdateGroup: string;
  groupId: number;
  values = '';
  alreadytaken: boolean = false;
  alreadytakenedit: boolean = false;
  constructor(private service: MailboxserviceService, private toaster: ToastrService) {
  }

  ngOnInit() {
    this.service.GroupMaster().subscribe(k => {
      this.groupData = k;
      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 8, pagingType: 'full_numbers'
    };
  }
  addUserMaster(groupMasterData) {
    this.service.AddUpdateGroupMaster(groupMasterData.value).subscribe(k => {
      this.toaster.success('Group Added Successfully', 'Success');
      this.service.GroupMaster().subscribe(k => {
        this.groupData = k;
      });
    });
  }
  toUpdate(groupName, groupId) {
    this.toUpdateGroup = groupName;
    this.groupId = groupId;
  }

  editUserMaster(editgroupMasterData) {
    this.service.AddUpdateGroupMaster(editgroupMasterData.value).subscribe(k => {
      this.toaster.success('Group Updated Successfully', 'Success');
      $("#editGroup").modal('hide');
      this.service.GroupMaster().subscribe(k => {
        this.groupData = k;
      });
    });
  }
  deleteUserMaster(groupId) {
    this.service.DeleteGroupMaster(groupId).subscribe(k => {
      this.toaster.info('Group Deleted Successfully', 'Success');
      $("#deleteGroup").modal('hide');
      this.service.GroupMaster().subscribe(k => {
        this.groupData = k;
      });
    });
  }

  // onDrop(event: CdkDragDrop<any[]>) {
  //   if (event.previousContainer === event.container) {
  //     moveItemInArray(event.container.data,
  //       event.previousIndex, event.currentIndex);
  //     console.log(event.previousIndex, event.currentIndex)
  //   } else {
  //     transferArrayItem(event.previousContainer.data,
  //       event.container.data,
  //       event.previousIndex,
  //       event.currentIndex);
  //   }
  // }
  onChange(event: any) {
    this.values = event.target.value;
    this.service.chkgroupName(this.values).subscribe((data: any) => {
      this.alreadytaken = false;
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.alreadytaken = true;
      };
    });
  }
  oneditChange(event: any) {
    this.values = event.target.value;
    this.service.chkgroupName(this.values).subscribe((data: any) => {
      this.alreadytakenedit = false;
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.alreadytakenedit = true;
      };
    });
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  reset() {
    this.alreadytaken = false;
    this.alreadytakenedit = false;

  }
}
