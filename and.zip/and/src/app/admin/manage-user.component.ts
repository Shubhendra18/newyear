import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styles: []
})
export class ManageUserComponent implements OnInit {
  groupData: any = [];
  defaultgroup = null;
  values = '';
  alreadytaken: boolean = false;
  constructor(private service: MailboxserviceService, private toaster: ToastrService) { }

  ngOnInit() {
    this.service.GroupMaster().subscribe(k => {
      this.groupData = k;
    });
  }
  onChange(event: any) {
    this.values = event.target.value;
    this.service.chkName(this.values).subscribe((data: any) => {
      this.alreadytaken = false;
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.alreadytaken = true;
      };
    });
  }
  addNewUser(addUser) {
    if (this.alreadytaken == false) {
      this.service.AddUser(addUser.value).subscribe((data: any) => {
        this.toaster.success('User Added successfully!', 'Success');
      }, (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toaster.error('Something went wrong', 'Error');
        };
      });
    }
    else {
      Swal.fire({
        icon: 'warning',
        title: 'Please try Another user Name!',
        text: "Warning",
      })
    }
  }
  reset() {
    this.alreadytaken = false;
  }
}
