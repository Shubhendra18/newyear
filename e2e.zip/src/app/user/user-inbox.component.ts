import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
import { HttpErrorResponse } from '@angular/common/http';
import * as CryptoJS from 'crypto-js';

declare var $;

@Component({
  selector: 'app-user-inbox',
  templateUrl: './user-inbox.component.html',
  styles: []
})
export class UserInboxComponent implements OnInit {
  @ViewChild('openModal', { static: true }) openModal: ElementRef;
  private allmails: any = [];
  SelectedIDs: any = [];
  i: number = 0;
  allmailtotrash: boolean = false;
  decrypt = localStorage.getItem("userToken").toString();
  Rid = CryptoJS.AES.decrypt(this.decrypt.trim(), "ut").toString(CryptoJS.enc.Utf8);

  isimportant = "text-dark";
  broadcastmsg = {};
  p: number = 1;
  brodhide = true;
  broadcastpic = "";
  status: any;
  profilepic = "";
  baseurl: any = "";
  constructor(private service: MailboxserviceService, private toastr: ToastrService) {
    this.baseurl = this.service.getbaseurl();

  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.buttonClick.subscribe(data => {
      this.status = data;
    })


    this.service.getmail(this.Rid).subscribe(k => {
      this.allmails = k;
    });
    this.service.BroadcastGet(this.Rid).subscribe(k => {
      if (k != null) {
        this.broadcastmsg = k;
        this.brodhide = false;
        if (k['thumbnailPic'] != null) {
          this.broadcastpic = this.baseurl + "/Broadcastpics/" + k['thumbnailPic']
        }
        this.openModal.nativeElement.click();
      }
      else {
        this.brodhide = true;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.brodhide = false;
      }
    });
  }
  checkAll(ev) {
    this.allmails.forEach(x => x.state = ev.target.checked);
    this.allmailtotrash = (ev.currentTarget.checked);

  }
  isAllChecked() {
    return this.allmails.every(_ => _.state);
  }
  deleteSelected() {
    if (this.allmailtotrash == true) {
      var moveToTrash = { 'Rid': this.Rid, 'flag': 0 };
      this.service.allMailsmoveToTrash(moveToTrash).subscribe(k => {
        if (k == "success") {
          this.toastr.success('Inbox is Empty!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Trash!', 'Error');
        }
      });
    }
    else {
      this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
        if (k == "Success") {
          this.toastr.info('Moved To Trash!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Trash!', 'Error');
        }
      });
    }
  }
  archivedSelected() {
    if (this.allmailtotrash == true) {
      var moveToArchive = { 'Rid': this.Rid, 'flag': 0 };
      this.service.allMailsmoveToArchive(moveToArchive).subscribe(k => {
        if (k == "success") {
          this.toastr.success('Moved To Archived!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Archived!', 'Error');
        }
      });
    }
    else {
      this.service.moveToArchive(this.SelectedIDs).subscribe(k => {
        if (k == "Success") {
          this.toastr.info('Moved To Archived!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Archived!', 'Error');
        }
      });
    }
  }

  FieldsChange(event: any, mailId) {
    this.SelectedIDs.push(mailId);
  }
  alltotrash(values: any) {
    this.allmailtotrash = (values.currentTarget.checked);
  }
  Refresh() {
    this.ngOnInit();
  }
  markasImportant(mailId) {
    this.service.moveToImportant(mailId).subscribe(k => {
      if (k == "success") {
        this.toastr.success('Moved To Important!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Archived!', 'Error');
      }
    });
  }
  broadcastseen(rowId) {
    this.service.MarkBroadcastSeen(rowId).subscribe();
  }
  trackByFn(index: number, item) {
    return index;
  }
}
