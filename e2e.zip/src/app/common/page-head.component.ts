import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-head',
  templateUrl: './page-head.component.html',
  styles: []
})
export class PageHeadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
